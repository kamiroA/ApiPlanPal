package com.PlanPal.Eventos_api.Config;



import java.io.FileInputStream;
import java.io.IOException;
import org.springframework.core.io.ClassPathResource;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import javax.annotation.PostConstruct;
import org.springframework.stereotype.Component;

@Component
public class FirebaseInitializer {

    @PostConstruct
    public void initialize() {
        try {
            // Carga el archivo de credenciales desde el classpath correctamente
            FileInputStream serviceAccount = new FileInputStream(new ClassPathResource("/serviceAccountKey.json").getFile());

            FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .setProjectId("proyectofinalciclo-a1049") // Ajusta según tu proyecto
                .build();

            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

