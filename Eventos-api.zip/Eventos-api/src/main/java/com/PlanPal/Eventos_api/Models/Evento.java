package com.PlanPal.Eventos_api.Models;

import java.util.Date;
import java.util.List;
import java.util.Map;

// Clase `Evento` adaptada para Firestore usando java.util.Date
public class Evento {

    private String codigo; // Código único del evento
    private String nombre; // Nombre del evento
    private String descripcion; // Descripción del evento
    private Date horaInicio; // Hora de inicio del evento
    private Date horaFin; // Hora de finalización del evento
    private List<Date> horasDisponibles; // Horas concretas disponibles para citas
    private Map<Date, String> citasReservadas; // Horas reservadas y el ID del usuario que reservó
    private String creadorId; // ID del usuario creador del evento

    // Constructor vacío
    public Evento() {}

    // Getters y Setters
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public Date getHoraInicio() {
        return horaInicio;
    }
    public void setHoraInicio(Date horaInicio) {
        this.horaInicio = horaInicio;
    }
    public Date getHoraFin() {
        return horaFin;
    }
    public void setHoraFin(Date horaFin) {
        this.horaFin = horaFin;
    }
    public List<Date> getHorasDisponibles() {
        return horasDisponibles;
    }
    public void setHorasDisponibles(List<Date> horasDisponibles) {
        this.horasDisponibles = horasDisponibles;
    }
    public Map<Date, String> getCitasReservadas() {
        return citasReservadas;
    }
    public void setCitasReservadas(Map<Date, String> citasReservadas) {
        this.citasReservadas = citasReservadas;
    }
    public String getCreadorId() {
        return creadorId;
    }
    public void setCreadorId(String creadorId) {
        this.creadorId = creadorId;
    }
}
