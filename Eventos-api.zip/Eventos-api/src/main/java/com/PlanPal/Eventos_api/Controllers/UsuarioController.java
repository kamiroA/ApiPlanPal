package com.PlanPal.Eventos_api.Controllers;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.PlanPal.Eventos_api.Models.Usuario;
import com.PlanPal.Eventos_api.Services.UsuarioService;

import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    /**
     * Registra un nuevo usuario en Firestore.
     *
     * @param usuario Datos del usuario a registrar.
     * @param result Validación de la petición.
     * @return El usuario registrado o errores.
     */
    @PostMapping("/registrar")
    public ResponseEntity<?> registrarUsuario(@RequestBody @Valid Usuario usuario, BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(result.getFieldErrors());
        }
        try {
            Usuario nuevoUsuario = usuarioService.registrarUsuario(usuario);
            return ResponseEntity.status(201).body(nuevoUsuario);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al registrar usuario: " + e.getMessage());
        }
    }

    /**
     * Obtiene todos los usuarios registrados.
     *
     * @return Lista de usuarios.
     */
    @GetMapping
    public ResponseEntity<?> obtenerUsuarios() {
        try {
            List<Usuario> usuarios = usuarioService.getAllUsuarios();
            return ResponseEntity.ok(usuarios);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error al obtener usuarios: " + e.getMessage());
        }
    }

    /**
     * Obtiene un usuario por su ID.
     *
     * @param id ID del usuario.
     * @return Datos del usuario o error si no se encuentra.
     */
    @GetMapping("/{id}")
    public ResponseEntity<?> obtenerUsuarioPorId(@PathVariable String id) {
        try {
            Usuario usuario = usuarioService.getUsuarioById(id);
            return ResponseEntity.ok(usuario);
        } catch (Exception e) {
            return ResponseEntity.status(404).body("Usuario no encontrado: " + e.getMessage());
        }
    }

    /**
     * Elimina un usuario.
     *
     * @param id ID del usuario a eliminar.
     * @return Mensaje de confirmación o error.
     */
    @DeleteMapping("/{id}/eliminar")
    public ResponseEntity<?> eliminarUsuario(@PathVariable String id) {
        try {
            usuarioService.deleteUsuario(id);
            return ResponseEntity.ok("Usuario eliminado correctamente.");
        } catch (Exception e) {
            return ResponseEntity.status(400).body("Error al eliminar usuario: " + e.getMessage());
        }
    }

    /**
     * Sube la foto de perfil de un usuario.
     *
     * @param id ID del usuario.
     * @param file Archivo de imagen.
     * @return Mensaje de confirmación o error.
     */
    @PostMapping("/{id}/subirFoto")
    public ResponseEntity<?> subirFotoDePerfil(@PathVariable String id, @RequestParam("file") MultipartFile file) {
        try {
            if (!file.getContentType().startsWith("image")) {
                return ResponseEntity.badRequest().body("El archivo debe ser una imagen.");
            }
            usuarioService.guardarFotoDePerfil(id, file);
            return ResponseEntity.ok("Foto de perfil guardada correctamente.");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error al guardar la foto de perfil: " + e.getMessage());
        }
    }
}
