package com.PlanPal.Eventos_api.DTO;

import jakarta.validation.constraints.NotNull;
import java.util.Date;

public class CitaRequest {
    
    @NotNull(message = "La hora de la cita es requerida")
    private Date hora;
    
    @NotNull(message = "El ID del usuario es requerido")
    private String usuarioId;

    public Date getHora() {
        return hora;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }
}
