package com.PlanPal.Eventos_api.repositories;



import com.PlanPal.Eventos_api.Models.Evento;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Repository
public class EventoRepository {

    private static final String COLLECTION_EVENTOS = "eventos";
    private final Firestore firestore;

    public EventoRepository() {
        // Se obtiene la instancia de Firestore, que ya ha sido inicializada mediante FirebaseInitializer
        this.firestore = FirestoreClient.getFirestore();
    }

    /**
     * Guarda un nuevo Evento en Firestore. Se genera un ID autogenerado y se asigna a la propiedad 'codigo'.
     *
     * @param evento La instancia de Evento a guardar.
     * @return El ID generado para el evento.
     * @throws ExecutionException, InterruptedException
     */
    public String saveEvento(Evento evento) throws ExecutionException, InterruptedException {
        CollectionReference eventos = firestore.collection(COLLECTION_EVENTOS);
        DocumentReference docRef = eventos.document();
        evento.setCodigo(docRef.getId());
        ApiFuture<WriteResult> future = docRef.set(evento);
        future.get();
        return docRef.getId();
    }

    /**
     * Busca un Evento en Firestore por su código (ID).
     *
     * @param codigo El código (ID) del evento.
     * @return La instancia de Evento, o null si no se encuentra.
     * @throws ExecutionException, InterruptedException
     */
    public Evento findEventoByCodigo(String codigo) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection(COLLECTION_EVENTOS).document(codigo);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        DocumentSnapshot document = future.get();
        if (document.exists()) {
            return document.toObject(Evento.class);
        }
        return null;
    }

    /**
     * Retorna una lista de todos los eventos almacenados en Firestore.
     *
     * @return Lista de instancias Evento.
     * @throws ExecutionException, InterruptedException
     */
    public List<Evento> findAllEventos() throws ExecutionException, InterruptedException {
        List<Evento> eventosList = new ArrayList<>();
        ApiFuture<QuerySnapshot> query = firestore.collection(COLLECTION_EVENTOS).get();
        for (QueryDocumentSnapshot document : query.get().getDocuments()) {
            eventosList.add(document.toObject(Evento.class));
        }
        return eventosList;
    }

    /**
     * Actualiza un evento existente. Se utiliza el campo 'codigo' para identificar el documento.
     *
     * @param evento La instancia de Evento que se desea actualizar.
     * @throws ExecutionException, InterruptedException
     */
    public void updateEvento(Evento evento) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection(COLLECTION_EVENTOS).document(evento.getCodigo());
        ApiFuture<WriteResult> future = docRef.set(evento);
        future.get();
    }

    /**
     * Elimina un Evento de Firestore mediante su código (ID).
     *
     * @param codigo El código (ID) del evento a eliminar.
     * @throws ExecutionException, InterruptedException
     */
    public void deleteEvento(String codigo) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection(COLLECTION_EVENTOS).document(codigo);
        ApiFuture<WriteResult> future = docRef.delete();
        future.get();
    }
}
