package com.PlanPal.Eventos_api.Services;

import com.PlanPal.Eventos_api.Models.Usuario;
import com.PlanPal.Eventos_api.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ExecutionException;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

    @Autowired
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Registra y guarda un nuevo usuario en Firestore.
     * Asigna un ID generado al objeto y lo retorna.
     *
     * @param usuario El usuario a crear.
     * @return El usuario registrado, con su ID.
     */
    public Usuario registrarUsuario(Usuario usuario) {
        try {
            String id = usuarioRepository.saveUsuario(usuario);
            usuario.setId(id);
            return usuario;
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al registrar el usuario", e);
        }
    }

    /**
     * Retorna la lista de todos los usuarios.
     */
    public List<Usuario> getAllUsuarios() {
        try {
            return usuarioRepository.findAllUsuarios();
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al obtener los usuarios", e);
        }
    }

    /**
     * Obtiene un usuario por su ID.
     */
    public Usuario getUsuarioById(String id) {
        try {
            return usuarioRepository.findUsuarioById(id);
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al obtener el usuario", e);
        }
    }

    /**
     * Elimina un usuario por su ID.
     */
    public void deleteUsuario(String id) {
        try {
            usuarioRepository.deleteUsuario(id);
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al eliminar el usuario", e);
        }
    }

    /**
     * Procesa y guarda la foto de perfil para el usuario.
     * (Método de ejemplo; la lógica de almacenamiento deberá ser implementada, por ejemplo, en Firebase Storage.)
     */
    public void guardarFotoDePerfil(String id, org.springframework.web.multipart.MultipartFile file) {
        // Implementa la lógica para subir la imagen y actualizar el objeto Usuario aquí.
        throw new UnsupportedOperationException("El método guardarFotoDePerfil aún no está implementado");
    }
}
