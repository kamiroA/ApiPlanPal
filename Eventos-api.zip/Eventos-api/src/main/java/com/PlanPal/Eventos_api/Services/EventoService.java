package com.PlanPal.Eventos_api.Services;

import com.PlanPal.Eventos_api.Models.Evento;
import com.PlanPal.Eventos_api.repositories.EventoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@Service
public class EventoService {

    private final EventoRepository eventoRepository;

    @Autowired
    public EventoService(EventoRepository eventoRepository) {
        this.eventoRepository = eventoRepository;
    }

    /**
     * Crea y guarda un nuevo evento en Firestore.
     * Retorna el objeto Evento con su código asignado.
     */
    public Evento createEvento(Evento evento) {
        try {
            String id = eventoRepository.saveEvento(evento);
            evento.setCodigo(id);
            return evento;
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al crear el evento", e);
        }
    }

    /**
     * Retorna la lista de todos los eventos.
     */
    public List<Evento> getAllEventos() {
        try {
            return eventoRepository.findAllEventos();
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al obtener los eventos", e);
        }
    }

    /**
     * Actualiza un evento existente a partir de su código.
     * Se espera que el objeto 'evento' traiga los datos actualizados.
     */
    public Evento updateEvento(String codigo, Evento evento) {
        try {
            // Asigna el código del evento a actualizar
            evento.setCodigo(codigo);
            eventoRepository.updateEvento(evento);
            return evento;
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al actualizar el evento", e);
        }
    }

    /**
     * Elimina un evento a partir de su código.
     */
    public void deleteEvento(String codigo) {
        try {
            eventoRepository.deleteEvento(codigo);
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al eliminar el evento", e);
        }
    }

    /**
     * Reserva una cita en un evento.
     *
     * @param codigo    Código del evento.
     * @param hora      Fecha y hora de la cita a reservar.
     * @param usuarioId ID del usuario que reserva.
     */
    public void reservarCita(String codigo, Date hora, String usuarioId) {
        try {
            Evento evento = eventoRepository.findEventoByCodigo(codigo);
            if (evento == null) {
                throw new RuntimeException("Evento no encontrado");
            }
            // Inicializa el mapa de citas si es nulo
            if (evento.getCitasReservadas() == null) {
                evento.setCitasReservadas(new HashMap<>());
            }
            // Agrega la cita; aquí podrías agregar lógica adicional para
            // verificar si la hora está disponible o no
            evento.getCitasReservadas().put(hora, usuarioId);
            eventoRepository.updateEvento(evento);
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al reservar la cita", e);
        }
    }

    /**
     * Obtiene el mapa de citas reservadas de un evento.
     */
    public Map<Date, String> getCitasReservadas(String codigo) {
        try {
            Evento evento = eventoRepository.findEventoByCodigo(codigo);
            if (evento != null) {
                return evento.getCitasReservadas();
            }
            return new HashMap<>();
        } catch (ExecutionException | InterruptedException e) {
            throw new RuntimeException("Error al obtener citas reservadas", e);
        }
    }
}
