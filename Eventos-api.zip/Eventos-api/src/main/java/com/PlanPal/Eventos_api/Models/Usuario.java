package com.PlanPal.Eventos_api.Models;

import java.util.List;

// Clase `Usuario` preparada para Firestore
public class Usuario {

    private String id; // Identificador único del usuario

    private String nombre; // Nombre de usuario o empresa

    private String correo; // Correo electrónico

    private String contrasena; // Contraseña

    private String fotoPerfil; // Imagen codificada en Base64

    private String informacionAdicional; // Datos adicionales como enlaces o teléfonos

    private List<String> eventosCreadosIds; // Lista de IDs de eventos creados por el usuario

    // Constructor vacío
    public Usuario() {}

    // Getters y setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getFotoPerfil() {
        return fotoPerfil;
    }

    public void setFotoPerfil(String fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

    public String getInformacionAdicional() {
        return informacionAdicional;
    }

    public void setInformacionAdicional(String informacionAdicional) {
        this.informacionAdicional = informacionAdicional;
    }

    public List<String> getEventosCreadosIds() {
        return eventosCreadosIds;
    }

    public void setEventosCreadosIds(List<String> eventosCreadosIds) {
        this.eventosCreadosIds = eventosCreadosIds;
    }
}
