package com.PlanPal.Eventos_api.repositories;

import com.PlanPal.Eventos_api.Models.Usuario;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

@Repository
public class UsuarioRepository {

    private static final String COLLECTION_USUARIOS = "usuarios";
    private final Firestore firestore;

    public UsuarioRepository() {
        // Se obtiene la instancia preconfigurada de Firestore
        this.firestore = FirestoreClient.getFirestore();
    }

    /**
     * Guarda un nuevo Usuario en Firestore. Genera un ID autogenerado que se asigna al campo 'id'.
     *
     * @param usuario La instancia de Usuario a guardar.
     * @return El ID asignado.
     * @throws ExecutionException, InterruptedException
     */
    public String saveUsuario(Usuario usuario) throws ExecutionException, InterruptedException {
        CollectionReference usuarios = firestore.collection(COLLECTION_USUARIOS);
        DocumentReference docRef = usuarios.document();
        usuario.setId(docRef.getId());
        ApiFuture<WriteResult> future = docRef.set(usuario);
        future.get();
        return docRef.getId();
    }

    /**
     * Busca un Usuario por su ID.
     *
     * @param id El ID del usuario.
     * @return La instancia de Usuario, o null si no se encuentra.
     * @throws ExecutionException, InterruptedException
     */
    public Usuario findUsuarioById(String id) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection(COLLECTION_USUARIOS).document(id);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        DocumentSnapshot document = future.get();
        if (document.exists()) {
            return document.toObject(Usuario.class);
        }
        return null;
    }

    /**
     * Retorna una lista de todos los usuarios registrados en Firestore.
     *
     * @return Lista de instancias Usuario.
     * @throws ExecutionException, InterruptedException
     */
    public List<Usuario> findAllUsuarios() throws ExecutionException, InterruptedException {
        List<Usuario> usuariosList = new ArrayList<>();
        ApiFuture<QuerySnapshot> query = firestore.collection(COLLECTION_USUARIOS).get();
        for (QueryDocumentSnapshot document : query.get().getDocuments()) {
            usuariosList.add(document.toObject(Usuario.class));
        }
        return usuariosList;
    }

    /**
     * Actualiza la información de un usuario existente.
     *
     * @param usuario La instancia de Usuario con el campo 'id' previamente establecido.
     * @throws ExecutionException, InterruptedException
     */
    public void updateUsuario(Usuario usuario) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection(COLLECTION_USUARIOS).document(usuario.getId());
        ApiFuture<WriteResult> future = docRef.set(usuario);
        future.get();
    }

    /**
     * Elimina un Usuario de Firestore mediante su ID.
     *
     * @param id El ID del usuario a eliminar.
     * @throws ExecutionException, InterruptedException
     */
    public void deleteUsuario(String id) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection(COLLECTION_USUARIOS).document(id);
        ApiFuture<WriteResult> future = docRef.delete();
        future.get();
    }
}
