package com.PlanPal.Eventos_api.Controllers;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.PlanPal.Eventos_api.Models.Evento;
import com.PlanPal.Eventos_api.Services.EventoService;
import com.PlanPal.Eventos_api.DTO.CitaRequest;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/eventos")
public class EventoController {

    @Autowired
    private EventoService eventoService;

    /**
     * Crear un nuevo evento en Firestore.
     *
     * @param evento Datos del evento a crear.
     * @param result Objeto para capturar errores de validación.
     * @return El evento creado o errores.
     */
    @PostMapping("/crear")
    public ResponseEntity<?> crearEvento(@RequestBody @Valid Evento evento, BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(result.getFieldErrors());
        }
        try {
            Evento nuevoEvento = eventoService.createEvento(evento);
            return ResponseEntity.status(201).body(nuevoEvento);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al crear el evento: " + e.getMessage());
        }
    }

    /**
     * Obtiene todos los eventos desde Firestore.
     *
     * @return Lista de eventos.
     */
    @GetMapping
    public ResponseEntity<?> obtenerEventos() {
        try {
            List<Evento> eventos = eventoService.getAllEventos();
            return ResponseEntity.ok(eventos);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error al obtener los eventos: " + e.getMessage());
        }
    }

    /**
     * Reserva una cita en un evento.
     *
     * @param codigo Código del evento donde se reserva.
     * @param citaRequest Datos de la cita (hora y usuarioId).
     * @param result Validación de la petición.
     * @return Mensaje de éxito o error.
     */
    @PostMapping("/{codigo}/reservar")
    public ResponseEntity<?> reservarCita(@PathVariable String codigo,
                                            @RequestBody @Valid CitaRequest citaRequest,
                                            BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(result.getFieldErrors());
        }
        try {
            eventoService.reservarCita(codigo, citaRequest.getHora(), citaRequest.getUsuarioId());
            return ResponseEntity.ok("Cita reservada correctamente.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al reservar cita: " + e.getMessage());
        }
    }

    /**
     * Modifica un evento existente.
     *
     * @param codigo Código único del evento a modificar.
     * @param evento Datos actualizados del evento.
     * @param result Validación de los datos entrantes.
     * @return El evento actualizado o errores.
     */
    @PutMapping("/{codigo}/modificar")
    public ResponseEntity<?> modificarEvento(@PathVariable String codigo,
                                               @RequestBody @Valid Evento evento,
                                               BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(result.getFieldErrors());
        }
        try {
            Evento eventoActualizado = eventoService.updateEvento(codigo, evento);
            return ResponseEntity.ok(eventoActualizado);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al modificar el evento: " + e.getMessage());
        }
    }

    /**
     * Elimina un evento.
     *
     * @param codigo Código del evento a eliminar.
     * @return Mensaje de confirmación o error.
     */
    @DeleteMapping("/{codigo}/eliminar")
    public ResponseEntity<?> eliminarEvento(@PathVariable String codigo) {
        try {
            eventoService.deleteEvento(codigo);
            return ResponseEntity.ok("Evento eliminado correctamente.");
        } catch (Exception e) {
            return ResponseEntity.status(404).body("Error al eliminar el evento: " + e.getMessage());
        }
    }

    /**
     * Consulta las citas reservadas de un evento.
     *
     * @param codigo Código del evento.
     * @return Mapa de citas reservadas.
     */
    @GetMapping("/{codigo}/citas")
    public ResponseEntity<?> obtenerCitasReservadas(@PathVariable String codigo) {
        try {
            Map<?, ?> citas = eventoService.getCitasReservadas(codigo);
            return ResponseEntity.ok(citas);
        } catch (Exception e) {
            return ResponseEntity.status(404).body("Error al obtener las citas: " + e.getMessage());
        }
    }
}
