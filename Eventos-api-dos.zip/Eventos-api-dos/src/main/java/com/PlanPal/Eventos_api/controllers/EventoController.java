package com.PlanPal.Eventos_api.controllers;

import com.PlanPal.Eventos_api.models.Evento;
import com.PlanPal.Eventos_api.repository.EventoRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@Tag(name = "Eventos API", description = "API para gestionar eventos en Firestore")
@RestController
@RequestMapping("/eventos")
public class EventoController {

    private final EventoRepository eventoRepository;

    public EventoController(EventoRepository eventoRepository) {
        this.eventoRepository = eventoRepository;
    }

    /**
     * Crea un nuevo evento en Firestore.
     *
     * Requerimientos:
     * - El request debe incluir un JSON con todos los datos del evento.
     *
     * URL: POST /eventos
     * Respuestas:
     * - 201: Evento creado con el ID asignado.
     * - 500: Error interno al crear el evento.
     */
    @Operation(summary = "Crear un nuevo evento", description = "Crea un nuevo evento en la colección 'eventos' de Firestore. Se debe enviar un JSON con la representación completa del evento.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Evento creado con éxito."),
        @ApiResponse(responseCode = "500", description = "Error interno al crear el evento.")
    })
    @PostMapping
    public ResponseEntity<String> createEvento(@RequestBody Evento evento) {
        try {
            String id = eventoRepository.save(evento);
            return ResponseEntity.status(HttpStatus.CREATED).body("Evento creado con ID: " + id);
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error creando el evento: " + e.getMessage());
        }
    }

    /**
     * Recupera un evento dado su ID.
     *
     * Requerimientos:
     * - El path parameter {id} debe corresponder a un documento existente.
     *
     * URL: GET /eventos/{id}
     * Respuestas:
     * - 200: Retorna el evento encontrado.
     * - 404: Evento no encontrado.
     * - 500: Error interno al recuperar el evento.
     */
    @Operation(summary = "Obtener un evento por ID", description = "Recupera un evento específico a partir del ID del documento en Firestore.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Evento encontrado exitosamente."),
        @ApiResponse(responseCode = "404", description = "No se encontró el evento con el ID proporcionado."),
        @ApiResponse(responseCode = "500", description = "Error interno al recuperar el evento.")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Evento> getEventoById(@PathVariable String id) {
        try {
            Evento evento = eventoRepository.findById(id);
            if (evento == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
            return ResponseEntity.ok(evento);
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Recupera la lista completa de eventos.
     *
     * URL: GET /eventos
     * Respuestas:
     * - 200: Retorna la lista de eventos.
     * - 500: Error interno al obtener la lista.
     */
    @Operation(summary = "Obtener todos los eventos", description = "Recupera la lista completa de eventos almacenados en Firestore.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Listado de eventos obtenido exitosamente."),
        @ApiResponse(responseCode = "500", description = "Error interno al recuperar la lista de eventos.")
    })
    @GetMapping
    public ResponseEntity<List<Evento>> getAllEventos() {
        try {
            List<Evento> eventos = eventoRepository.findAll();
            return ResponseEntity.ok(eventos);
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Actualiza completamente un evento existente.
     *
     * Requerimientos:
     * - El path parameter {id} debe corresponder a un evento existente.
     * - El request body debe contener la representación completa del evento.
     *
     * URL: PUT /eventos/{id}
     * Respuestas:
     * - 200: Evento actualizado con éxito.
     * - 404: Evento no encontrado.
     * - 500: Error interno al actualizar el evento.
     */
    @Operation(summary = "Actualizar un evento completamente", description = "Reemplaza por completo los datos de un evento existente. Se debe enviar el objeto completo del evento en el request.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Evento actualizado exitosamente."),
        @ApiResponse(responseCode = "404", description = "No se encontró el evento con el ID proporcionado."),
        @ApiResponse(responseCode = "500", description = "Error interno al actualizar el evento.")
    })
    @PutMapping("/{id}")
    public ResponseEntity<String> updateEvento(@PathVariable String id, @RequestBody Evento evento) {
        try {
            boolean success = eventoRepository.update(id, evento);
            if (success) {
                return ResponseEntity.ok("Evento actualizado exitosamente.");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Evento no encontrado.");
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error actualizando el evento: " + e.getMessage());
        }
    }

    /**
     * Realiza una actualización parcial de un evento.
     *
     * Requerimientos:
     * - El path parameter {id} debe corresponder a un evento existente.
     * - El request body debe contener un JSON con los campos a actualizar.
     *
     * URL: PATCH /eventos/{id}
     * Respuestas:
     * - 200: Evento actualizado parcialmente.
     * - 404: Evento no encontrado.
     * - 500: Error interno al actualizar el evento.
     */
    @Operation(summary = "Actualización parcial de un evento", description = "Actualiza uno o más campos específicos de un evento existente. Solo se envían los datos que se desean modificar.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Evento actualizado parcialmente con éxito."),
        @ApiResponse(responseCode = "404", description = "Evento no encontrado con el ID proporcionado."),
        @ApiResponse(responseCode = "500", description = "Error interno al actualizar el evento.")
    })
    @PatchMapping("/{id}")
    public ResponseEntity<String> patchEvento(@PathVariable String id, @RequestBody Map<String, Object> updates) {
        try {
            boolean success = eventoRepository.patchUpdate(id, updates);
            if (success) {
                return ResponseEntity.ok("Evento actualizado parcialmente.");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Evento no encontrado.");
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error actualizando el evento: " + e.getMessage());
        }
    }

    /**
     * Elimina un evento existente.
     *
     * Requerimientos:
     * - El path parameter {id} debe corresponder a un evento existente.
     *
     * URL: DELETE /eventos/{id}
     * Respuestas:
     * - 200: Evento eliminado exitosamente.
     * - 404: Evento no encontrado.
     * - 500: Error interno al eliminar el evento.
     */
    @Operation(summary = "Eliminar un evento", description = "Elimina un evento existente de Firestore basándose en su ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Evento eliminado exitosamente."),
        @ApiResponse(responseCode = "404", description = "No se encontró el evento a eliminar."),
        @ApiResponse(responseCode = "500", description = "Error interno al eliminar el evento.")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEvento(@PathVariable String id) {
        try {
            boolean success = eventoRepository.delete(id);
            if (success) {
                return ResponseEntity.ok("Evento eliminado exitosamente.");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Evento no encontrado.");
            }
        } catch (ExecutionException | InterruptedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error eliminando el evento: " + e.getMessage());
        }
    }
}
