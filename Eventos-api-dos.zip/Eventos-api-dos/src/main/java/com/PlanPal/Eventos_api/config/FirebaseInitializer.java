package com.PlanPal.Eventos_api.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.cloud.FirestoreClient;
import com.google.cloud.firestore.Firestore;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.io.InputStream;

@Component
public class FirebaseInitializer {

    @Value("${firebase.credentials.path}")
    private String firebaseCredentialsPath;
    private Firestore firestore;

    @PostConstruct
    public void init() throws IOException {
        // Se carga el archivo utilizando la ruta externalizada en application.properties
        ClassPathResource resource = new ClassPathResource(firebaseCredentialsPath);
        if (!resource.exists()) {
            throw new IOException("No se encontró el archivo " + firebaseCredentialsPath + " en el classpath");
        }
        InputStream serviceAccountStream = resource.getInputStream();

        FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccountStream))
                .build();

        FirebaseApp.initializeApp(options);
        firestore = FirestoreClient.getFirestore();
        System.out.println("Firebase inicializado correctamente usando el recurso '" + firebaseCredentialsPath + "'");
    }

    public Firestore getFirestore() {
        return firestore;
    }
}
