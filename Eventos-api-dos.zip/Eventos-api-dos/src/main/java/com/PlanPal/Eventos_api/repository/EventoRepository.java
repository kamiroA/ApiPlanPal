package com.PlanPal.Eventos_api.repository;

import com.PlanPal.Eventos_api.models.Evento;
import com.PlanPal.Eventos_api.config.FirebaseInitializer;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@Repository
public class EventoRepository {

    private final Firestore firestore;

    public EventoRepository(FirebaseInitializer firebaseInitializer) {
        this.firestore = firebaseInitializer.getFirestore();
    }

    // Crea un nuevo evento y retorna el id generado por Firestore.
    public String save(Evento evento) throws ExecutionException, InterruptedException {
        CollectionReference eventos = firestore.collection("eventos");
        ApiFuture<DocumentReference> future = eventos.add(evento);
        return future.get().getId();
    }

    // Recupera un evento por su ID.
    public Evento findById(String documentId) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection("eventos").document(documentId);
        ApiFuture<DocumentSnapshot> future = docRef.get();
        DocumentSnapshot document = future.get();
        if (document.exists()) {
            return document.toObject(Evento.class);
        }
        return null;
    }

    // Retorna la lista de todos los eventos.
    public List<Evento> findAll() throws ExecutionException, InterruptedException {
        CollectionReference eventos = firestore.collection("eventos");
        ApiFuture<QuerySnapshot> future = eventos.get();
        QuerySnapshot querySnapshot = future.get();
        return querySnapshot.toObjects(Evento.class);
    }

    // Reemplaza completamente un evento existente en Firestore.
    // Retorna true si se actualizó, false si no existe.
    public boolean update(String id, Evento evento) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection("eventos").document(id);
        DocumentSnapshot docSnapshot = docRef.get().get();
        if (!docSnapshot.exists()) {
            return false;
        }
        // Se reemplaza el documento completo.
        ApiFuture<WriteResult> future = docRef.set(evento);
        future.get();
        return true;
    }

    // Actualiza parcialmente un evento (solo los campos especificados en el Map).
    // Retorna true si se actualizó, false si no existe.
    public boolean patchUpdate(String id, Map<String, Object> updates) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection("eventos").document(id);
        DocumentSnapshot docSnapshot = docRef.get().get();
        if (!docSnapshot.exists()) {
            return false;
        }
        ApiFuture<WriteResult> future = docRef.update(updates);
        future.get();
        return true;
    }

    // Elimina un evento y retorna true si se eliminó, o false si no se encontró.
    public boolean delete(String id) throws ExecutionException, InterruptedException {
        DocumentReference docRef = firestore.collection("eventos").document(id);
        DocumentSnapshot docSnapshot = docRef.get().get();
        if (!docSnapshot.exists()) {
            return false;
        }
        ApiFuture<WriteResult> future = docRef.delete();
        future.get();
        return true;
    }
}
