package com.PlanPal.Eventos_api.models;


import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
public class Evento {
    private String codigo;           // Ejemplo: "E001"
    private String descripcion;      // Ejemplo: "Reunión de equipo"
    private String creadorId;        // Ejemplo: "usuario123"
    private String horaInicio;       // Ejemplo: "2025-05-05T09:00:00"
    private String horaFin;          // Ejemplo: "2025-05-05T09:30:00"
    private List<String> horasDisponibles;  // Ejemplo: ["2025-05-04T09:00:00", "2025-05-04T09:30:00"]
    private Map<String, String> citasReservadas; // Ejemplo: {"2025-05-04T09:00:00": "Alejandro"}
}
